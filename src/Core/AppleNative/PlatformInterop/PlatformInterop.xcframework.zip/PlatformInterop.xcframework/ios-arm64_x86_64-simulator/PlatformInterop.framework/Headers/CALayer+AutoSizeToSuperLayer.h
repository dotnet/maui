#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface CALayer (AutoSizeToSuperLayer)

@property (nonatomic, assign) BOOL autoSizeToSuperLayer;

@end
